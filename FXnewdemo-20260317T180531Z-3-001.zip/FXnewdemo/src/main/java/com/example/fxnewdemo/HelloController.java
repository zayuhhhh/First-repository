package com.example.fxnewdemo;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HelloController {

    @FXML
    private Label welcomeText;

    @FXML
    private Button closeButton; // Field must be at the class level

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Placeholder button");
    }



}



