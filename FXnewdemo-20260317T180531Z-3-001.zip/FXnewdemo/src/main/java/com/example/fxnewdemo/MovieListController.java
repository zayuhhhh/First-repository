package com.example.fxnewdemo;

import javafx.fxml.FXML;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MovieListController {

    @FXML private Accordion movieAccordion;
    @FXML private Label movieTitleLabel;
    @FXML private ImageView moviePoster;

    // Base path to your images folder within resources
    private final String IMAGE_DIR = "/com/example/fxnewdemo/images/";

    @FXML
    public void initialize() {
        // --- Setting the Default Image ---
        // Load the reel icon so the screen isn't empty on startup
        try {
            Image defaultImg = new Image(getClass().getResourceAsStream(IMAGE_DIR + "Default.png"));
            moviePoster.setImage(defaultImg);
        } catch (NullPointerException e) {
            System.err.println("Default.png not found at: " + IMAGE_DIR);
        }

        // --- Setting up the Selection Listener ---
        // This listens for whenever a user opens a new movie pane
        movieAccordion.expandedPaneProperty().addListener((observable, oldPane, newPane) -> {
            if (newPane != null) {
                // Get the text from the TitledPane
                String selectedMovieTitle = newPane.getText();
                updateDetailView(selectedMovieTitle);
            }
        });
    }

    /**
     * Updates the UI on the left with the correct title and poster.
     * @param movieName The exact text from the selected TitledPane.
     */
    private void updateDetailView(String movieName) {
        // 1. Update the Title text
        movieTitleLabel.setText(movieName);

        // 2. Map the movie title to its exact filename from your folder
        String posterFilename = "";

        // This checks the Title text and finds the matching image
        // Make sure these match the text in your FXML perfectly!
        if (movieName.contains("Supergirl")) {
            posterFilename = "Supergirl.jpg";
        } else if (movieName.contains("Chainsaw Man")) {
            posterFilename = "ChainsawMoveReze.jpg";
        } else if (movieName.contains("Spider-Man Brand New Day")) {
            posterFilename = "Spiderman.jpg"; // Based on your image filename
        }

        // 3. Update the Image if a match was found
        if (!posterFilename.isEmpty()) {
            try {
                // Combine base directory with filename
                String fullPath = IMAGE_DIR + posterFilename;
                Image posterImg = new Image(getClass().getResourceAsStream(fullPath));
                moviePoster.setImage(posterImg);
            } catch (NullPointerException e) {
                System.err.println("Poster not found: " + IMAGE_DIR + posterFilename);
                // Optional: Fall back to default if poster is missing
                // moviePoster.setImage(new Image(...Default.png...));
            }
        }
    }
}