module com.example.fxnewdemo {
    requires javafx.controls;
   requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.fxnewdemo to javafx.fxml;
    exports com.example.fxnewdemo;
}