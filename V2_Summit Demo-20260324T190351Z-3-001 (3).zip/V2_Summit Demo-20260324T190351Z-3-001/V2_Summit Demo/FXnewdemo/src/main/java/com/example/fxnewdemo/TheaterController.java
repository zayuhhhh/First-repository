package com.example.fxnewdemo;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class TheaterController {

    @FXML
    private GridPane seatingGrid; // Linked to the GridPane in FXML

    @FXML
    private Label freeSeatsLabel; // Linked to the "28 free seats" Label

    @FXML
    private Label nowPlayingLabel; // Linked to the "Now Playing: Supergirl" Label

    private int freeSeats = 28;

    @FXML
    public void initialize() {
        // Rows A through D as per your sketch
        String[] rowLetters = {"A", "B", "C", "D"};
        int columns = 10;

        // Clear the grid if you put dummy data in Scene Builder
        seatingGrid.getChildren().clear();

        for (int r = 0; r < rowLetters.length; r++) {
            // 1. Add the Row Letter (A, B, C, D) to the first column
            Label rowLabel = new Label(rowLetters[r]);
            rowLabel.setStyle("-fx-font-weight: bold; -fx-padding: 0 10 0 0;");
            seatingGrid.add(rowLabel, 0, r);

            for (int c = 1; c <= columns; c++) {
                // 2. Create a "Seat" Button
                Button seat = new Button();
                seat.setPrefSize(35, 30);

                // Set initial "Available" style (White)
                seat.setStyle("-fx-background-color: white; -fx-border-color: black; -fx-border-radius: 3;");

                // 3. Define what happens when a seat is clicked
                seat.setOnAction(event -> handleSeatSelection(seat));

                // Add to grid: column c, row r
                seatingGrid.add(seat, c, r);
            }
        }

        // Set initial text
        freeSeatsLabel.setText(freeSeats + " free seats");
    }

    private void handleSeatSelection(Button seat) {
        // Toggle logic: If white (Available), turn black (Booked)
        if (seat.getStyle().contains("white")) {
            seat.setStyle("-fx-background-color: black; -fx-border-color: #555555; -fx-border-radius: 3;");
            freeSeats--;
        } else {
            // If black (Booked), turn back to white (Available)
            seat.setStyle("-fx-background-color: white; -fx-border-color: black; -fx-border-radius: 3;");
            freeSeats++;
        }

        // Update the counter label
        freeSeatsLabel.setText(freeSeats + " free seats");
    }

    // You can call this method from the first controller to set the movie name!
    public void setMovieTitle(String title) {
        nowPlayingLabel.setText("Now Playing: " + title);
    }
}