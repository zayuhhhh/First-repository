package com.example.fxnewdemo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // 1. Load your initial view
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));

        // 2. Create the scene without the 320x240 restriction
        Scene scene = new Scene(fxmlLoader.load());

        stage.setTitle("Summit Cinemas - Booking System");
        stage.setScene(scene);

        // 3. Make the window fill the screen but keep the taskbar and top buttons

        stage.setMaximized(true);

        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}