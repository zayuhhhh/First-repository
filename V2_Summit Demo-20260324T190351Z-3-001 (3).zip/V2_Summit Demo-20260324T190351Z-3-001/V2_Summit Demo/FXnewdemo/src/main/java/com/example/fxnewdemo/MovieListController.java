package com.example.fxnewdemo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class MovieListController {

    @FXML private Accordion movieAccordion;
    @FXML private Label movieTitleLabel;
    @FXML private ImageView moviePoster;

    private final String IMAGE_DIR = "/com/example/fxnewdemo/images/";

    @FXML
    public void initialize() {
        try {
            Image defaultImg = new Image(getClass().getResourceAsStream(IMAGE_DIR + "Default.png"));
            moviePoster.setImage(defaultImg);
        } catch (Exception e) {
            System.err.println("Default.png not found at: " + IMAGE_DIR);
        }

        movieAccordion.expandedPaneProperty().addListener((observable, oldPane, newPane) -> {
            if (newPane != null) {
                updateDetailView(newPane.getText());
            }
        });
    }

    private void updateDetailView(String movieName) {
        movieTitleLabel.setText(movieName);
        String posterFilename = "";

        // Matches the titles in your Accordion TitledPanes
        if (movieName.contains("Supergirl")) {
            posterFilename = "Supergirl.jpg";
        } else if (movieName.contains("Chainsaw Man")) {
            posterFilename = "ChainsawMoveReze.jpg";
        } else if (movieName.contains("Spider-Man Brand New Day")) {
            posterFilename = "Spiderman.jpg";
        }

        if (!posterFilename.isEmpty()) {
            try {
                String fullPath = IMAGE_DIR + posterFilename;
                Image posterImg = new Image(getClass().getResourceAsStream(fullPath));
                moviePoster.setImage(posterImg);
            } catch (Exception e) {
                System.err.println("Poster not found: " + IMAGE_DIR + posterFilename);
            }
        }
    }


    @FXML
    private void goToTheater(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("theater-view.fxml"));
            Parent root = loader.load();

            // Pass the movie name to the theater controller
            TheaterController controller = loader.getController();
            controller.setMovieTitle(movieTitleLabel.getText());

            // Switch the scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));

            // Keep window maximized for the theater grid
            stage.setMaximized(true);
            stage.show();

        } catch (IOException e) {
            System.err.println("Could not load theater-view.fxml. Check the filename!");
            e.printStackTrace();
        }
    }

    @FXML
    private void goBackToHome(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setMaximized(true);
            stage.show();
        } catch (IOException e) {
            System.err.println("Could not load hello-view.fxml");
        }
    }
}