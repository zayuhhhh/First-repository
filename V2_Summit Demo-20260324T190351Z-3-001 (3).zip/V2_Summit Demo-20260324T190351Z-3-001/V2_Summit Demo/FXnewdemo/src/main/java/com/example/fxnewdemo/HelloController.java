package com.example.fxnewdemo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {

    @FXML
    private Label welcomeText;

    @FXML
    private Button closeButton;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Placeholder button");
    }

    /**
     * Switches the scene to the Film List with a fixed window size.
     */
    @FXML
    private void switchToFilmList(ActionEvent event) {
        try {
            // 1. Load your film-list.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("film-list.fxml"));
            Parent root = loader.load();

            // 2. Get the current Stage (the window)
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // 3. Set the new Scene with fixed dimensions (1000 wide, 700 high)
            // This ensures the window doesn't shrink or move to the corner.
            Scene scene = new Scene(root, 1000, 700);
            stage.setScene(scene);

            // 4. Center the window on the screen for a cleaner look
            stage.centerOnScreen();

            stage.show();

        } catch (IOException e) {
            System.err.println("Error: Could not find film-list.fxml");
            e.printStackTrace();
        }
    }

    @FXML
    private void closeApp() {
        System.exit(0);
    }
}